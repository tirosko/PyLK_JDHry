https://inventwithpython.com/pygame/buggy/
Bug Descriptions:

Wormy
wormy_buggy1.py - Červ sa niekedy nezobrazí na hracej ploche a „Game Over“ sa objaví o sekundu alebo dve neskôr.
wormy_buggy2.py - Červ neustále rastie.
wormy_buggy3.py - Stlačením šípky dole ide červ hore.
wormy_buggy4.py - Červ môže prejsť cez ľavý a pravý okraj.
wormy_buggy5.py - Program zamrzne s čiernou obrazovkou pri štarte.
wormy_buggy6.py - NameError: globálny názov 'DOWN' nie je definovaný
wormy_buggy7.py - Neviditeľná vertikálna stena v strede spôsobí, že hráč prehrá.
wormy_buggy8.py - Hráč nemôže zmeniť smer a stlačením šípky doľava nastane game over.
